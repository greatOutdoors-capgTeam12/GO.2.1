import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-user-login-form',
  templateUrl: './user-login-form.component.html',
  styleUrls: ['./user-login-form.component.css']
})
export class UserLoginFormComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

}
