export class ResolvedProductList
{
    
}