export class Order{
    userId: String ;
	addressId: String ;
}