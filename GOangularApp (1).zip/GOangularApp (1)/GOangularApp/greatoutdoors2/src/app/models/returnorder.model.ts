export class ReturnOrder{
    userid:string;
    orderid:string;
    reason:string;
}