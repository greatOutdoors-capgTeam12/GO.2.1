export class cart{
    userId: String;
    productId: String;
    quantity: String;
   
}